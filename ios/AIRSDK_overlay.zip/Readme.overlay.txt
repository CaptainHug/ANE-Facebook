These files are needed to use the ANE Facebook extension with AIR SDK version 30.0.0.107

You need to extract the archive into the root of your AIRSDK folder.
