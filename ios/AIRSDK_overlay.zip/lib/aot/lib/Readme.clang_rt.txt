These files have been taken from the Xcode 9.0 Toolchain
